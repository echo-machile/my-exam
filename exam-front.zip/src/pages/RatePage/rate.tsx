import React, { useState, useEffect, useRef } from 'react';
import {
  Card,
  Radio,
  Button,
  Col,
  Typography,
  Image,
  Input,
  Affix,
  List,
  Anchor,
  message,
  Row,
  Modal,
} from 'antd';
import { withRouter,history } from 'umi';
import Countdown from 'react-countdown';
import {getUserAnswers, submitGradedScores} from '@/services/exams/exam';
import { useParams } from 'umi';

const { TextArea } = Input;
const { Link } = Anchor;
const { confirm } = Modal;

interface GradedScore {
  userAnswerId: number;
  score: number;
}

const Index = ({ }) => {
  const { userId, examId } = useParams<{ examId: string }>();
  const examIdNumber = parseInt(examId, 10);
  const userIdNumber = parseInt(userId, 10);
  console.log("Exam ID:", examIdNumber);
  console.log("User ID:", userIdNumber);

  const [questions, setQuestions] = useState([]);
  const [gradedScores, setGradedScores] = useState({});
  const questionRefs = useRef([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await getUserAnswers(userIdNumber, examIdNumber);
      await setQuestions(response.map(userAnswer=>{
        userAnswer.question.answerText = userAnswer.answerText;
        userAnswer.question.selectedOptions = userAnswer.selectedOptions;
        return userAnswer.question;
      }));
      console.log("这是question"+JSON.stringify(questions));
    };
    fetchData();
  }, []);

  const handleSubmit = async () => {
    confirm({
      title: '确认提交打分？',
      content: '提交后将无法修改打分，是否继续？',
      onOk: async () => {
        const formattedGradedScores: GradedScore[] = Object.entries(gradedScores).map(([userAnswerId, score]) => ({
          userAnswerId: parseInt(userAnswerId, 10),
          examId:examIdNumber,
          userId:userIdNumber,
          score: score,
        }));
        await submitGradedScores(formattedGradedScores);
        // 在此处添加 history.goBack()
        history.push("/ratePages");
        message.success("打分已提交!");
      },
    });
  };
  const truncate = (str, maxLength = 30) => {
    return str.length > maxLength ? str.slice(0, maxLength) + '...' : str;
  };

  return (
    <>
      <Row gutter={[16, 16]} style={{ display: 'flex' }}>
        <Col span={18} style={{ flex: 1 }}>
          {questions?.map((question, index) => {
            const { id, text, imagePath, category, questionType, options, answerText,selectedOptions  } = question;

            return (
              <div
                key={index}
                ref={(el) => (questionRefs.current[index] = el)}
                style={{ marginBottom: 32 }}
              >
                <Card>
                  <div>
                    <Typography.Title level={4} style={{ marginBottom: 16 }}>
                      {`${index + 1}. ${text}`}
                    </Typography.Title>
                    {imagePath &&
                      <Image
                        width="100%"
                        src={'/elect/' + imagePath}
                        style={{ maxWidth: 300, marginBottom: 16 }}
                        preview={false}
                        objectFit="contain"
                      />
                    }

                    {questionType === 'objective' && (
                      <>
                        <Radio.Group
                          value={selectedOptions}
                          style={{ marginBottom: 16 }}
                        >
                          {options.map((option,
                                        optionIndex) => (
                            <Radio
                              key={optionIndex}
                              value={option.id}
                              style={{ display: 'block', marginBottom: 8 }}
                              disabled
                            >
                              {option.text}{
                              option.imagePath&& <Image
                                src={'/elect'+option.imagePath}
                                style={{ maxWidth: 100, marginBottom: 16 }}
                              ></Image>
                            }

                            </Radio>
                          ))}
                        </Radio.Group>
                      </>
                    )}
                    {questionType === 'subjective' && (
                      <TextArea
                        rows={4}
                        placeholder="请在此输入您的答案"
                        value={answerText}
                        style={{ marginBottom: 16 }}
                        disabled
                      />
                    )}
                    {questionType === 'subjective' && (<Input
                      type="number"
                      min={0}
                      max={100}
                      placeholder="输入分数"
                      style={{ width: 100, marginLeft: 16 }}
                      defaultValue={0}
                      onChange={(e) => {
                        const score = parseInt(e.target.value, 10);
                        setGradedScores({ ...gradedScores, [id]: score });
                      }}
                    />)}
                  </div>
                </Card>
              </div>
            );
          })}
          <Button
            type="primary"
            onClick={handleSubmit}
            size="large"
            style={{
              display: 'block',
              marginLeft: 'auto',
              marginRight: 'auto',
              marginBottom: 32,
            }}
          >
            提交打分
          </Button>
        </Col>
        <Col span={6}>
          <Affix offsetTop={20}>
            <List
              header={<div style={{ fontWeight: 'bold', fontSize: '18px' }}>题目索引</div>}
              bordered
              dataSource={questions}
              renderItem={(question, index) => (
                <List.Item
                  onClick={() =>
                    questionRefs.current[index].scrollIntoView({
                      behavior: 'smooth',
                    })
                  }
                  style={{
                    cursor: 'pointer',
                    padding: '12px 24px',
                    marginBottom: 8,
                    borderRadius: 5,
                    backgroundColor: '#F0F2F5',
                    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.1)',
                  }}
                >
                  <span style={{ fontWeight: 'bold' }}>{index + 1}.</span> {truncate(question.text)}
                </List.Item>
              )}
            />
          </Affix>
        </Col>
      </Row>
    </>
  );
};

export default withRouter(Index);
