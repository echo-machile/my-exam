import React, { useEffect, useState } from 'react';
import { useParams } from 'umi';
import { Card, List,Typography  } from 'antd';
import {getAllExamResults, getExamResults} from '@/services/exams/exam';

const { Text } = Typography;

const ExamResults: React.FC = () => {
  const { examId } = useParams<{ examId: string }>();
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    if(examId == '0'){
      const response = await getAllExamResults();
      setResults(response);
      setLoading(false);
    }else {
      const response = await getExamResults(examId);
      setResults(response);
      setLoading(false);
    }


  };

  return (
    <Card title="Exam Results" loading={loading}>
      <List
        dataSource={results}
        renderItem={(item: any) => (
          <List.Item>
            <List.Item.Meta
              title={<Text>{item.user.username}</Text>}
              description={`实训项目: ${item.exam.title}`}
            />
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end',
                flexGrow: 1,
              }}
            >
              <Text style={{ color: 'green', fontWeight: 'bold', fontSize: '1.5em' }}>
                {`分数: ${item.score}`}
              </Text>
            </div>
          </List.Item>
        )}
      />
    </Card>
  );
};

export default ExamResults;
