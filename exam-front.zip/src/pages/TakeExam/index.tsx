import React, { useEffect, useState } from 'react';
import { useParams } from 'umi';
import { Card } from 'antd';
import { getExam, submitExam } from '@/services/exams/exam';
import ExamForm from './ExamForm';

const TakeExam: React.FC = () => {
  const { examId } = useParams<{ examId: string }>();
  const [exam, setExam] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const response = await getExam(examId);
    setExam(response.data);
    setLoading(false);
  };

  const handleSubmit = async (answers: any[]) => {
    await submitExam(examId, answers);
  };

  return (
    <Card title={exam?.title} loading={loading}>
      <ExamForm questions={exam?.questions} onSubmit={handleSubmit} />
    </Card>
  );
};

export default TakeExam;
