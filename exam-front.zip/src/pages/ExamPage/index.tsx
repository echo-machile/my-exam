import React, { useState, useEffect, useRef } from 'react';
import {
  Card,
  Radio,
  Button,
  Col,
  Typography,
  Image,
  Input,
  Affix,
  List,
  Anchor,
  message,
  Row,
  Modal,
} from 'antd';
// @ts-ignore
import { withRouter } from 'umi';
import Countdown from 'react-countdown';
import { getExam, getQuestions, submitExam } from '@/services/exams/exam';
import { useParams } from 'react-router-dom';
import {number} from "prop-types";

const { TextArea } = Input;
const { Link } = Anchor;
const { confirm } = Modal;
const Index = ({ history }) => {
  const { examId } = useParams<{ examId: string }>();
  const examIdNumber = parseInt(examId, 10);
  console.log('Exam ID:', examIdNumber);

  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});

  const questionRefs = useRef([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await getExam(examId);
      setQuestions(response.questions);
    };
    fetchData();
  }, []);

  const handleAnswerChange = (questionId, value) => {
    setAnswers({ ...answers, [questionId]: value });
    console.log("答案改变:", { ...answers, [questionId]: value });
  };

  function getRemainingTime() {
    const remainingTime = localStorage.getItem("remainingTime");
    return remainingTime ? parseInt(remainingTime) : 1000 * 60 * 30;
  }

  function setRemainingTime(time) {
    localStorage.setItem("remainingTime", time);
  }



  const handleSubmit = async () => {
    if (questions.length !== Object.keys(answers).length) {
      message.error("请回答所有问题");
      return;
    }
    confirm({
      title: '确认提交答案？',
      content: '提交后将无法修改答案，是否继续？',
      onOk: async () => {
        console.log("答案集合"+answers);
        const formattedAnswers = Object.entries(answers).map(([questionId, answer]) => ({
          userId:sessionStorage.getItem("currentUserId"),
          questionId: parseInt(questionId, 10),
          examId:examIdNumber,
          selectedOptions: typeof answer==="number"?answer:Array.isArray(answer) ? answer?.join(',') : null,
          answerText: typeof answer === 'string' ? answer : null,
        }));
        const answersArray = Object.entries(answers).map(([questionId, answer]) => {
          return {
            questionId: parseInt(questionId, 10),
            answer: answer,
          };
        });
        await submitExam(examIdNumber,formattedAnswers);
        // 在此处添加 history.goBack()
        history.goBack();
        message.success("考试完成!");
      },
    });
  };

  const renderer = ({ minutes, seconds, completed }) => {
    if (completed) {
      message.warning('时间到！自动提交答案');
      handleSubmit();
      return <span>时间结束</span>;
    } else {
      return (
        <span>
          剩余时间：{minutes}分{seconds}秒
        </span>
      );
    }
  };

  const truncate = (str, maxLength = 30) => {
    return str.length > maxLength ? str.slice(0, maxLength) + '...' : str;
  };

  return (
    <>
      <Row gutter={[16, 16]} style={{ display: 'flex' }}>
        <Col span={18} style={{ flex: 1 }}>
        {questions?.map((question, index) => {
          const { id, text, imagePath, category, questionType, options } = question;

          return (
            <div
              key={index}
              ref={(el) => (questionRefs.current[index] = el)}
              style={{ marginBottom: 32 }}
            >
              <Card>
                <div>
                  <Typography.Title level={4} style={{ marginBottom: 16 }}>
                    {`${index + 1}. ${text}`}
                  </Typography.Title>{
                  imagePath&&(
                    <Image
                      width="100%"
                      src={'/elect/' + imagePath}
                      style={{ maxWidth: 300, marginBottom: 16 }}
                      preview={false}
                      objectFit="contain"
                    />
                  )
                }

                  {questionType === 'objective' && (
                    <>
                      <Radio.Group
                        onChange={(e) => handleAnswerChange(id, e.target.value)}
                        style={{ marginBottom: 16 }}
                      >
                        {options.map((option, optionIndex) => (
                          <Radio
                            key={optionIndex}
                            value={option.id}
                            style={{ display: 'block', marginBottom: 8 }}
                          >
                            {option.text}{
                            option.imagePath&&(
                              <Image
                                src={'/elect'+option.imagePath}
                                style={{ maxWidth: 100, marginBottom: 16 }}
                              ></Image>
                            )
                          }

                          </Radio>

                        ))}
                      </Radio.Group>
                    </>
                  )}
                  {questionType === 'subjective' && (
                    <TextArea
                      rows={4}
                      placeholder="请在此输入您的答案"
                      onChange={(e) => handleAnswerChange(id, e.target.value)}
                      style={{ marginBottom: 16 }}
                    />
                  )}
                </div>
              </Card>
            </div>
          );
        })}
          <Button
            type="primary"
            onClick={handleSubmit}
            size="large"
            style={{
              display: 'block',
              marginLeft: 'auto',
              marginRight: 'auto',
              marginBottom: 32,
            }}
          >
            提交答案
          </Button>
      </Col>
        <Col span={6}>
          <Affix offsetTop={20}>
            <Card>
              <Typography.Title level={4} style={{ textAlign: 'center' }}>
                计时器
              </Typography.Title>
              <Countdown
                date={Date.now() + getRemainingTime()} // 倒计时 30 分钟
                renderer={({ minutes, seconds, completed }) => {
                  if (completed) {
                    message.warning('时间到！自动提交答案');
                    handleSubmit();
                    return <span>时间结束</span>;
                  } else {
                    setRemainingTime(minutes * 60 * 1000 + seconds * 1000);
                    return (
                      <span
                        style={{
                          fontSize: '24px',
                          fontWeight: 'bold',
                          color: '#FF4D4F',
                        }}
                      >
                        {minutes}分{seconds}秒
                      </span>
                    );
                  }
                }}
              />
            </Card>
            <List
              header={<div style={{ fontWeight: 'bold', fontSize: '18px' }}>题目索引</div>}
              bordered
              dataSource={questions}
              renderItem={(question, index) => (
                <List.Item
                  onClick={() =>
                    questionRefs.current[index].scrollIntoView({
                      behavior: 'smooth',
                    })
                  }
                  style={{
                    cursor: 'pointer',
                    padding: '12px 24px',
                    marginBottom: 8,
                    borderRadius: 5,
                    backgroundColor: '#F0F2F5',
                    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.1)',
                  }}
                >
                  <span style={{ fontWeight: 'bold' }}>{index + 1}.</span> {truncate(question.text)}
                </List.Item>
              )}
            />
          </Affix>
        </Col>
      </Row>
    </>
  );
};

export default withRouter(Index);
