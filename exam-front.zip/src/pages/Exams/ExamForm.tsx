// import React from 'react';
// import { Button, Form, Input, DatePicker } from 'antd';
//
// const ExamForm: React.FC<{ initialValues?: any; onSubmit: (values: any) => void }> = ({
//                                                                                         initialValues,
//                                                                                         onSubmit,
//                                                                                       }) => {
//   const [form] = Form.useForm();
//
//   const handleSubmit = (values: any) => {
//     onSubmit(values);
//     form.resetFields();
//   };
//
//   return (
//     <Form
//       form={form}
//       initialValues={initialValues}
//       onFinish={handleSubmit}
//       layout="vertical"
//     >
//       <Form.Item
//         label="Title"
//         name="title"
//         rules={[{ required: true, message: 'Please input the exam title!' }]}
//       >
//         <Input />
//       </
import React, {useState} from 'react';
import {Button, Form, Input, DatePicker, Space, DatePickerProps, Checkbox} from 'antd';
import {RangePickerProps} from "antd/es/date-picker";
import {string} from "prop-types";
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';

const ExamForm: React.FC<{ initialValues?: any; onSubmit: (values: any) => void }> = ({
                                                                                        initialValues,
                                                                                        onSubmit,
                                                                                      }) => {
  const [form] = Form.useForm();


  const { RangePicker } = DatePicker;
  const [date,setDate] = useState([]);
  const onChange = (
    value: DatePickerProps['value'] | RangePickerProps['value'],
    dateString: [string, string] | string,
  ) => {
    console.log('Selected Time: ', value);
    console.log('Formatted Selected Time: ', dateString);
    setDate(dateString);
  };

  const onOk = (value: DatePickerProps['value'] | RangePickerProps['value']) => {
    console.log('onOk: ', value);
  };
  const handleSubmit = (values: any) => {
    values.startTime = date[0];
    values.endTime = date[1];
    values.date=null;
    onSubmit(values);
    form.resetFields();
    initialValues = null;
  };

  return (
    <Form
      form={form}
      initialValues={initialValues}
      onFinish={handleSubmit}
      layout="vertical"
    >
      <Form.Item
        label="ID"
        name="id"
      >
        <Input disabled />
      </Form.Item>
      <Form.Item
        label="Title"
        name="title"
        rules={[{ required: true, message: 'Please input the exam title!' }]}
      >
        <Input />
      </Form.Item>
      <Form.Item
        label="Date"
        name="date"
        rules={[{ required: true, message: 'Please select the exam date!' }]}
      >
          <RangePicker
            name={"time"}
            showTime={{ format: 'HH:mm' }}
            format="YYYY-MM-DD HH:mm"
            onChange={onChange}
            onOk={onOk}
          />
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
  );
};

export default ExamForm;
