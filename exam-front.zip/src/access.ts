import {message} from "antd";

/**
 * @see https://umijs.org/zh-CN/plugins/plugin-access
 * */
export default function access(initialState: { currentUser?: API.CurrentUser } | undefined) {
  message.success(initialState?.role)
  return {

    canAdmin: initialState && initialState?.role === 'admin',
  };
}
