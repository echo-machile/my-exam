package com.elect.electexam.Common.Security;

import cn.hutool.json.JSONUtil;
import cn.hutool.jwt.JWTUtil;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.Enitity.User;
import com.elect.electexam.untils.JwtUtils;
import com.elect.electexam.untils.Res;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Optional;
import com.google.gson.Gson;

/**
 * 登陆成功处理器
 */
@Component
public class loginSuccessHandler implements AuthenticationSuccessHandler {

    @Autowired
    private UserService sysUserService;
    

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {

        response.setContentType("application/json;charset=UTF-8");

        ServletOutputStream outputStream = response.getOutputStream();

        String username = authentication.getName();
        String token = JwtUtils.genJwtToken(username);

        System.out.println("最终下发的签名: "+token);
        Optional<User>  admin = sysUserService.getByUserName(username);

        Res r = (Res) Res.ok("登陆成功");
        r.put("authorization", token);
        r.put("currentUserId",admin.get().getId());
        r.put("currentUserName",admin.get().getUsername());
        r.put("currentUserRole",admin.get().getRole());
        r.put("avatarUrl",admin.get().getAvatarUrl());


        StringBuffer authority = new StringBuffer();
        //根据用户id获取所有角色信息
        //List<SysRole> roleList = sysRoleService.ListRole((long) admin.getAdmin_id());


        //遍历所有角色，获取所有菜单权限，而且不重复

//        Set<SysMenu> menuSet =new HashSet<>();
//        for(SysRole sysRole:roleList){
//
//            List<SysMenu> menus = sysMenuService.List(sysRole.getId());
//            for(SysMenu menu:menus){
//                menuSet.add(menu);
//            }
//        }
//
//        List<SysMenu> sysMenus = new ArrayList<>(menuSet);
//
//        sysMenus.sort(Comparator.comparing(SysMenu::getOrderNum));
//
//
//        List<SysMenu> menuList = sysMenuService.buildTreeMenu(sysMenus);

        outputStream.write(JSONUtil.toJsonStr(r).getBytes());
        outputStream.flush();
        outputStream.close();
    }
}
