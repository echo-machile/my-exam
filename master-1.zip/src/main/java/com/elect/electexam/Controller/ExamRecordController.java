package com.elect.electexam.Controller;


import com.elect.electexam.Enitity.ExamRecord;
import com.elect.electexam.Enitity.ExamRecordInfo;
import com.elect.electexam.Enitity.User;
import com.elect.electexam.Service.ExamRecordService;
import com.elect.electexam.Service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/examRecords")
public class ExamRecordController {

    @Autowired
    ExamRecordService examRecordService;
    @GetMapping("/{userId}/results")
    public List<ExamRecord> getExamResults(@PathVariable Long userId, @AuthenticationPrincipal User user) {
        System.out.println("userid："+userId);
        List<ExamRecord> examRecords = examRecordService.findByUserId(userId);;
        System.out.println("这是记录: "+examRecords);
        return examRecords;
    }


    @GetMapping("/{userId}/{examId}/results")
    public List<ExamRecord> getExamResultsByUserIdAndExamId(@PathVariable Long userId, @PathVariable Long examId, @AuthenticationPrincipal User user) {
        System.out.println("userid："+userId+"examId: "+examId);
        List<ExamRecord> examRecords = examRecordService.findByUser_IdAndExam_Id(userId,examId);;
        System.out.println("这是记录: "+examRecords);
        return examRecords;
    }


}
