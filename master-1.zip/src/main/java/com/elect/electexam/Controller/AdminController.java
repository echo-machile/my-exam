package com.elect.electexam.Controller;

import com.elect.electexam.Enitity.Option;
import com.elect.electexam.Enitity.Question;
import com.elect.electexam.Enitity.QuestionType;
import com.elect.electexam.Enitity.User;
import com.elect.electexam.Service.ExamService;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.Service.lmp.UserServicelmp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserServicelmp userService;

    @Autowired
    private ExamService examService;

    @GetMapping("/users")
    public ResponseEntity<Map<String,Object>> getUsers(@RequestParam(required = false) Integer id,
                                                       @RequestParam(required = false) String username,
                                                       @RequestParam(required = false) String password,
                                                       @RequestParam(required = false) String email,
                                                       @RequestParam(required = false) String avatarUrl,
                                                       @RequestParam(required = false) String role,
                                                       @RequestParam(required = false) Integer current,
                                                       @RequestParam(required = false) Integer pageSize) {
        Pageable pageable = PageRequest.of(current != null ? current - 1 : 0, pageSize != null ? pageSize : 10);
        Page<User> users = userService.findFilteredUsers(id, username, password, email, avatarUrl,role, pageable);

        Map<String,Object> map = new HashMap<>();
        map.put("data",users.getContent());
        map.put("success",true);
        map.put("total",users.getTotalElements());
        return ResponseEntity.ok(map);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        User existingUser = userService.findById(id).get();
        if (existingUser == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        userService.deleteById(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }


    @PostMapping("/add")
    public ResponseEntity<User> createOrUpdateQuestion(@RequestBody User user) {
        System.out.println("新增用户"+user);
        return ResponseEntity.ok(userService.save(user));
    }
    // ... 其他管理员相关的 API 端点

    @PutMapping("/users/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User admin) {
        User user = userService.findById(id).get();
        System.out.println(user);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        userService.deleteById(id);
        System.out.println("删除成功！");
        admin.setId(id);
        User updatedUser = userService.save(admin);
        System.out.println(updatedUser);
        return ResponseEntity.ok(updatedUser);
    }

    @PostMapping("/remove")
    public void deleteQuestions(@RequestBody Map<String,List<Long>> map){
        System.out.println(map);
        for (Long id : map.get("key")) {
            userService.deleteById(id);
        }
    }
}
