package com.elect.electexam.Enitity;

public enum QuestionType {
    objective,
    subjective
}
