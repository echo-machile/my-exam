package com.elect.electexam.Enitity;

import lombok.Data;

@Data
public class RegistrationRequest {
    private String username;
    private String password;
    private String email;

    private String avatarUrl;

    // Getter and Setter methods
}
