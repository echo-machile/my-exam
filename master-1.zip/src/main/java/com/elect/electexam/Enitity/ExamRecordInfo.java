package com.elect.electexam.Enitity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class ExamRecordInfo {
    @Id
    private int id;
    private String username;
    private String title;

    private Integer score;

    // Constructors, getters, and setters

}
