package com.elect.electexam.Enitity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.util.List;
import java.util.Set;

@Entity
@Data
public class ExamQuestion {
    @Id
    private Long questionId;

}
