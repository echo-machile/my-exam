package com.elect.electexam.Service.lmp;

import com.elect.electexam.Enitity.*;
import com.elect.electexam.Jpa.ExamRecordRepository;
import com.elect.electexam.Jpa.ExamRepository;
import com.elect.electexam.Jpa.QuestionRepository;
import com.elect.electexam.Jpa.UserAnswerRepository;
import com.elect.electexam.Service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ExamServicelmp implements ExamService {

    @Autowired
    private ExamRecordRepository examRecordRepository;

    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private QuestionRepository questionRepository;


    @Autowired
    private UserAnswerRepository userAnswerRepository;

    public List<Exam> findAll() {
        return examRepository.findAll();
    }

    public Exam findById(Long id) {
        return examRepository.findById(id).orElse(null);
    }

    public Exam save(Exam exam) {
        return examRepository.save(exam);
    }

    public void deleteById(Long id) {
        examRepository.deleteById(id);
    }

    public Exam getExamById(Long examId) {
        return examRepository.findById(examId).orElse(null);
    }

    public ExamRecord submitAnswers(Long examId, List<UserAnswer> userAnswers, User user) {
        Exam exam = getExamById(examId);
        if (exam == null) {
            throw new IllegalArgumentException("Invalid exam id");
        }

        // 计算分数
        int score = calculateScore(userAnswers);

        System.out.println("用户总得分:"+score);


        // 保存考试记录
        ExamRecord examRecord = new ExamRecord(user, exam, score);
        examRecordRepository.save(examRecord);

        // 保存用户答案
        try{
            userAnswers.forEach(answer -> {
                //answer.setAnswerText();
                userAnswerRepository.save(answer);
            });
        }catch (Exception e){
            return null;
        }

        return examRecord;
    }

    @Override
    public boolean updateExams(Integer id,String title, Timestamp startTime, Timestamp endTime) {
        try {
            examRepository.updateMsg(title,startTime,endTime,id);
            return true;
        }catch (Exception  e){
            e.printStackTrace();
            return false;
        }

    }

    private int calculateScore(List<UserAnswer> userAnswers) {
        System.out.println("这是要计算的用户的答案>_<:"+userAnswers);
        int score = 0;

        for (UserAnswer userAnswer : userAnswers) {
            System.out.println("这是要计算的用户的答案>_<:"+userAnswer);
            Long questionId = userAnswer.getQuestion().getId();
            Question question = questionRepository.findById(questionId).orElse(null);

            if (question == null) {
                continue;
            }
            System.out.println("question不为空><"+question);
            if (question.getQuestionType().toString() == "objective") {
                List<Option> correctOptions = question.getOptions().stream()
                        .filter(Option::getCorrect)
                        .collect(Collectors.toList());
                System.out.println("问题的选项: "+correctOptions);
                List<Long> correctOptionIds = correctOptions.stream()
                        .map(Option::getId)
                        .collect(Collectors.toList());
                List<Long> selectedOptionIds = userAnswer.getSelectedOptionIds();
                System.out.println("问题的正确选项: "+correctOptionIds);

                System.out.println("用户答案:"+selectedOptionIds);

                System.out.println("用户答案包括正确答案:"+selectedOptionIds.containsAll(correctOptionIds));
                System.out.println("正确答案包括用户答案:"+correctOptionIds.containsAll(selectedOptionIds));

                // 比较正确答案和学生答案
                if (selectedOptionIds.containsAll(correctOptionIds) && correctOptionIds.containsAll(selectedOptionIds)) {


                    score += Optional.ofNullable(userAnswer.getScore()).orElse(1);
                    System.out.println("用户客观题的分:"+score);
                }
            } else {
                // 对于主观题，可以在这里实现自定义的评分逻辑
                // 示例：将主观题的得分设置为用户答案中的分数
                for(Option option:question.getOptions()){
                    String correctAnswer = option.getText();
                    System.out.println("主观题正确答案:"+correctAnswer);
                    String userAnswerText = userAnswer.getAnswerText();

                    System.out.println("用户答案:"+userAnswerText);
                    System.out.println(userAnswerText.equals(correctAnswer));

                    //double similarity = calculateAnswerSimilarity(correctAnswer, userAnswerText);
                    double subjectiveScore = 0;
                    if(userAnswerText.equals(correctAnswer)){
                        subjectiveScore = 3;
                    }
                    score += subjectiveScore;
                }
            }
            userAnswer.setScore(score);
        }

        return score;
    }


    private double calculateAnswerSimilarity(String correctAnswer, String userAnswerText) {
        // 在这里实现一个答案相似性计算方法
        // 示例：简单的比较两个字符串的相似程度（这只是一个简化的示例，实际应用中可以使用更复杂的算法）
        double similarity = 0.0;

        if (correctAnswer != null && userAnswerText != null) {
            int commonChars = 0;
            int minLength = Math.min(correctAnswer.length(), userAnswerText.length());

            for (int i = 0; i < minLength; i++) {
                if (correctAnswer.charAt(i) == userAnswerText.charAt(i)) {
                    commonChars++;
                }
            }

            similarity = (double) commonChars / minLength;
        }

        return similarity;
    }


    public ExamRecord getExamRecord(Long recordId) {
        return examRecordRepository.findById(recordId).orElse(null);
    }

    @Transactional
    public ExamRecord correctExam(Long recordId, List<UserAnswer> userAnswers) {
        ExamRecord examRecord = getExamRecord(recordId);
        if (examRecord == null) {
            throw new IllegalArgumentException("Invalid exam record id");
        }

        // 更新用户答案
        for (UserAnswer userAnswer : userAnswers) {
            userAnswerRepository.save(userAnswer);
        }

        // 重新计算分数
        int newScore = calculateScore(userAnswers);
        examRecord.setScore(newScore);
        examRecordRepository.save(examRecord);

        return examRecord;
    }


}
