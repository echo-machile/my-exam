package com.elect.electexam.Service.lmp;

import com.elect.electexam.Enitity.Question;
import com.elect.electexam.Enitity.RoleType;
import com.elect.electexam.Enitity.User;
import com.elect.electexam.Jpa.UserRepository;
import com.elect.electexam.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class UserServicelmp implements UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
        return userRepository.findAll();
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public User save(User user) {
        return userRepository.save(user);
    }

    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public Optional<User> getByUserName(String User) {
        return userRepository.findByUsername(User);
    }

    @Override
    public String getAuthorityInfo(long userId) {
            StringBuffer authority = new StringBuffer();
            authority.append("ROLE_admin,ROLE_common");
            //根据用户id获取所有角色信息
//        List<SysRole> roleList = sysRoleJpa.ListRole(userId);

//        if(roleList.size()>0){
//            String roleCode = roleList.stream().map(r ->"ROLE_"+r.getCode()).collect(Collectors.joining(","));
//            authority.append(roleCode);
//        }
            //遍历所有角色，获取所有菜单权限，而且不重复

            Set<String> menuCode =new HashSet<String>();
//        for(SysRole sysRole:roleList){
//
//            List<SysMenu> menus = sysMenuJpa.ListMenu(sysRole.getId());
//            for(SysMenu menu:menus){
//                String perms = menu.getPerms();
//                if(StringUtil.isNotEmpty(perms)){
//                    menuCode.add(perms);
//                }
//            }
//        }

//        if(menuCode.size()>0){
//            authority.append(",");
//
//            String menuCodeStrs = menuCode.stream().collect(Collectors.joining(","));
//
//            authority.append(menuCodeStrs);
//        }
//        System.out.println("authority: "+authority.toString());
            return authority.toString();
        }

    @Override
    public Page<User> findFilteredUsers(Integer id, String username, String password, String email, String avatarUrl, String role, Pageable pageable) {
        User user = new User();
        if (id != null) {
            user.setId(Long.valueOf(id));
        }
        if (username != null) {
            user.setUsername(username);
        }
        if (password != null) {
            user.setPassword(password);
        }
        if (email != null) {
            user.setEmail(email);
        }
        if (avatarUrl != null) {
            user.setAvatarUrl(avatarUrl);
        }

        if (role != null) {
            user.setRole(RoleType.valueOf(role));
        }

        ExampleMatcher matcher = ExampleMatcher.matchingAll()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
                .withIgnoreCase()
                .withIgnoreNullValues();

        Example<User> example = Example.of(user, matcher);
        return userRepository.findAll(example, pageable);
    }

}
