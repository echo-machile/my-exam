package com.elect.electexam.Service;

import com.elect.electexam.Enitity.Question;
import com.elect.electexam.Enitity.QuestionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface QuestionService {

    public List<Question> findAll();

    public Question findById(Long id);

    public Question save(Question question);

    public void deleteById(Long id);

    // QuestionService.java
    public Question saveQuestion(Question question);

    Page<Question> findFilteredQuestions(Long id, String text, String imagePath, String category, QuestionType questionType, Pageable pageable);


}
