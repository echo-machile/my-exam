package com.elect.electexam.Service.lmp;

import com.elect.electexam.Enitity.Question;
import com.elect.electexam.Enitity.QuestionType;
import com.elect.electexam.Jpa.QuestionRepository;
import com.elect.electexam.Service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionServicelmp implements QuestionService {
    @Autowired
    private QuestionRepository questionRepository;

    public List<Question> findAll() {
        return questionRepository.findAll();
    }

    public Question findById(Long id) {
        return questionRepository.findById(id).orElse(null);
    }

    public Question save(Question question) {
        return questionRepository.save(question);
    }

    public void deleteById(Long id) {
        questionRepository.deleteById(id);
    }

    @Override
    public Question saveQuestion(Question question) {
            // 更新选项中的问题引用
            question.getOptions().forEach(option -> option.setQuestion(question));
            // 保存问题及其选项
            return questionRepository.save(question);
    }


        @Override
        public Page<Question> findFilteredQuestions(Long id, String text, String imagePath, String category, QuestionType questionType, Pageable pageable) {
            Question probe = new Question();
            if (id != null) {
                probe.setId(id);
            }
            if (text != null) {
                probe.setText(text);
            }
            if (imagePath != null) {
                probe.setImagePath(imagePath);
            }
            if (category != null) {
                probe.setCategory(category);
            }
            if (questionType != null) {
                probe.setQuestionType(questionType);
            }

            ExampleMatcher matcher = ExampleMatcher.matchingAll()
                    .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
                    .withIgnoreCase()
                    .withIgnoreNullValues();

            Example<Question> example = Example.of(probe, matcher);
            return questionRepository.findAll(example, pageable);
        }

        // Other methods...

}
