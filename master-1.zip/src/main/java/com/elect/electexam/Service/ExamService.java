package com.elect.electexam.Service;

import com.elect.electexam.Enitity.*;
import com.elect.electexam.Jpa.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public interface ExamService {

    List<Exam> findAll();

    Exam findById(Long id);

    Exam save(Exam exam);

    void deleteById(Long id);

    ExamRecord getExamRecord(Long recordId);

    ExamRecord correctExam(Long recordId, List<UserAnswer> userAnswers);

    public ExamRecord submitAnswers(Long examId, List<UserAnswer> userAnswers, User user);


    boolean updateExams(Integer id,String title, Timestamp startTime, Timestamp endTime);
}
