package com.elect.electexam.Service;

import com.elect.electexam.Enitity.Question;
import com.elect.electexam.Enitity.QuestionType;
import com.elect.electexam.Enitity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface UserService {

    List<User> findAll();

    Optional<User> findById(Long id);

    User save(User user);

    void deleteById(Long id);

    Optional<User> getByUserName(String User);


    public String getAuthorityInfo(long userId);


    Page<User> findFilteredUsers(Integer id,
                                         String username,
                                         String password,
                                         String email,
                                         String avatarUrl,
                                         String role, Pageable pageable);
}
