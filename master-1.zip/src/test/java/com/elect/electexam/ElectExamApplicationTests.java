package com.elect.electexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
