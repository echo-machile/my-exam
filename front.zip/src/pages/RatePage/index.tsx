import React, { useState, useEffect } from 'react';
import { Table, Button } from 'antd';
import { history } from 'umi';
import {request} from "@umijs/max";
import {NoEmitOnErrorsPlugin} from "@umijs/bundler-webpack/compiled/webpack";

import style from './index.css'
const StudentAnswersPage: React.FC = () => {
  const [studentAnswers, setStudentAnswers] = useState<any[]>([]);

  // Fetch data from API
  useEffect(() => {
    const fetchData = async () => {
      const response = await request('/elect/exams/records/rate/getRecords',{
        method: 'get'
      });
      console.log(response);
      const data = await response;
      setStudentAnswers(data);
    };
    fetchData();
  }, []);

  const columns = [
    {
      title: '学生答案ID',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: '学生名字',
      dataIndex: ['user', 'username'],
      key: 'studentName',
    },
    {
      title: '考试名称',
      dataIndex: ['exam', 'title'],
      key: 'examName',
    },
    {
      title: '操作',
      key: 'action',
      render: (record: any) => (
        <Button
          onClick={() =>{
            console.log("内容:"+JSON.stringify(record));
            history.push(`/grading/${record.user.id}/${record.exam.id}`)
          }

          }
        >
          答题详情
        </Button>
      ),
    },
  ];

  return (
    <>
      <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>
        学生答题情况
      </h1>
      <Table columns={columns} dataSource={studentAnswers} />
    </>
  );
};

export default StudentAnswersPage;
