import React, {useState} from 'react';
import {Button, Form, Input, Select, Upload, Image, message, Space, Checkbox} from 'antd';
import {MinusCircleOutlined, PlusOutlined, UploadOutlined} from '@ant-design/icons';
import { QuestionType } from '@/constants/questionType';
import {val} from "@umijs/utils/compiled/cheerio/lib/api/attributes";
import {usage} from "@umijs/bundler-webpack/compiled/autoprefixer/browserslist";

const { Option } = Select;

const UserForm: React.FC<{ initialValues?: any; onSubmit: (values: any) => void;onCancel: (values: any) => void }> = ({
                                                                                            initialValues,
                                                                                            onSubmit,
  onCancel
                                                                                          }) => {
  const [form] = Form.useForm();
  const [img,setImg] = useState(null);
  const [img2,setImg2] = useState(null);

  console.log("初始值:"+JSON.stringify(initialValues));
  const handleSubmit = (values: any) => {
    //values.imagePath = img?img:initialValues?.imagePath;
    // values.options.imagePath = img2;
    onSubmit(values);
    form.resetFields();
  };

  const handleUpload = (file: any) => {
    // You can use a third-party library like 'axios' to send the file to your backend
    // For example:
    // const formData = new FormData();
    // formData.append('file', file);
    // axios.post('/api/upload', formData);

    // Simulating a successful upload:
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve("https://example.com/your-uploaded-image-url.jpg");
      }, 1000);
    });
  };

  return (
    <Form
      form={form}
      initialValues={initialValues?initialValues:{ role:"user"}}
      onFinish={handleSubmit}
      layout="vertical"
    >
      {/* ... other form items ... */}
      <Form.Item
        label="用户ID"
        name="id"
        // extra="填写题目内容"
      >
        <Input disabled></Input>
      </Form.Item>
      <Form.Item
        label="用户名称"
        name="username"
        rules={[{ required: true, message: '请输入用户名称!' }]}
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入用户名称"}></Input>
      </Form.Item>
      <Form.Item
        label="用户密码"
        name="password"
        rules={[{ required: true, message: '请输入用户密码!' }]}
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入用户密码"}></Input>
      </Form.Item>

      {/*<Form.Item*/}
      {/*  label="Image"*/}
      {/*  name="image"*/}
      {/*  valuePropName="fileList"*/}
      {/*  getValueFromEvent={(e) => (Array.isArray(e.fileList) ? e.fileList : [])}*/}
      {/*  extra="Select an image to upload"*/}
      {/*>*/}

      {/*  <Upload*/}
      {/*    //customRequest={({ file }) => handleUpload(file)}*/}
      {/*    accept="image/*"*/}
      {/*    showUploadList={false}*/}
      {/*    action="/elect/file/upload"*/}
      {/*    headers={{*/}
      {/*      Authorization: `Bearer ${sessionStorage.getItem("token")}`,*/}
      {/*      token: sessionStorage.getItem("token")*/}
      {/*    }}*/}

      {/*    onChange={(info) => {*/}
      {/*      if (info.file.status === 'done') {*/}
      {/*        console.log(info.file.response)*/}
      {/*        setImg(info.file.response)*/}
      {/*        message.success(`${info.file.name} 文件上传成功`);*/}
      {/*      } else if (info.file.status === 'error') {*/}
      {/*        message.error(`${info.file.name} 文件上传失败`);*/}
      {/*      }*/}
      {/*    }}*/}
      {/*  >*/}
      {/*    <Button icon={<UploadOutlined />}>Upload Image</Button>*/}
      {/*  </Upload>*/}
      {/*  <Image*/}
      {/*    width={200}*/}
      {/*    // defaultValue={initialValues?.imagePath}*/}

      {/*    src={img?'/elect'+img:'elect'+initialValues?.imagePath}*/}
      {/*  />*/}
      {/*</Form.Item>*/}
      <Form.Item
        label="用户邮箱:"
        name="email"
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入用户邮箱"}></Input>
      </Form.Item>

      <Form.Item
        label="用户头像地址:"
        name="avatarUrl"
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入用户头像地址"}></Input>
      </Form.Item>
      <Form.Item
        label="用户角色:"
        name="role"
        // extra="填写题目内容"
      >
        <Select defaultValue={"user"} showSearch>
          <Option value={"admin"}>管理员</Option>
          <Option value={"user"}>普通用户</Option>
        </Select>
      </Form.Item>
      <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit">
          确认
        </Button>
        <Button
          htmlType="button"
          style={{ marginLeft: '1rem' }}
          onClick={onCancel}
        >
          取消
        </Button>
      </Form.Item>

      {/* ... other form items ... */}
    </Form>
  );
};

export default UserForm;
