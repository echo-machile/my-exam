import React, {ReactText, useEffect, useRef, useState} from 'react';
import {Button, Card, Image, List, message, Modal, Progress, Select, Space, Tag} from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import UserForm from './UserForm';
import {
  getQuestions,
  deleteQuestion,
  saveQuestion,
  saveExam,
  getAllUsers,
  deleteUser,
  saveUsers
} from '@/services/exams/exam';
import {ActionType, FooterToolbar, ProList, ProTable} from "@ant-design/pro-components";
import {formatMessage, FormattedMessage} from "@@/exports";
import {request} from "@umijs/max";
import TakenExamForm from "@/pages/Questions/TakenExamForm";


const handleRemove = async (selectedRows: API.RuleListItem[]) => {
  const hide = message.loading('正在删除');
  if (!selectedRows) return true;
  console.log({
    key: selectedRows.map((row) => row.id),
  })

  try {
    await request("/elect/admin/remove",{
        method:"post",
        data: {
          key: selectedRows.map((row) => row.id),
        }
      }
    );
    hide();
    message.success('成功删除!');
    return true;
  } catch (error) {
    hide();
    message.error('Delete failed, please try again');
    return false;
  }
};
const Questions: React.FC = () => {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [takenExamModal, setTakenExamModal] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState(null);

  const [selectedRowKeys, setSelectedRowKeys] = useState<ReactText[]>([]);
  const rowSelection = {
    selectedRowKeys,
    onChange: (keys: ReactText[]) => setSelectedRowKeys(keys),
  };

  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.RuleListItem>();
  const [selectedRowsState, setSelectedRows] = useState<API.RuleListItem[]>([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const response = await getQuestions();
    setQuestions(response);
    setLoading(false);
  };

  const handleCreateOrUpdate = async (values: any) => {
    //console.log("values:"+values.imagePath)
    await saveUsers(values);
    setEditingQuestion(null);
    setModalVisible(false);
    actionRef.current?.reload();
  };

  const TakenExam = async (values: any)=>{
    console.log("发布考试相关信息:"+values)
    await saveExam(values);
    setTakenExamModal(false)
    actionRef.current?.reload();
  }
  const handleDelete = async (id: number) => {
    await deleteUser(id);
    message.success('用户删除成功!');
    fetchData();
    actionRef.current?.reload();
  };

  const openModal = (question: any) => {
    console.log("edit: "+JSON.stringify({...question}));
    setEditingQuestion(question);
    setModalVisible(true);
  };

  const closeModal = () => {
    setEditingQuestion(null);
    setModalVisible(false);
    actionRef.current?.reload();
  };

  const closeTakenExam = () => {
    setTakenExamModal(false);
    actionRef.current?.reload();
  };
  const columns =[
    {
      title: '用户ID',
      name:'id',
      dataIndex: 'id',
    },
    {
      title: '用户名称',
      name:'username',
      dataIndex: 'username',
    },
    {
      title: '用户邮箱',
      name:'email',
      dataIndex: 'email',
    },{
      title: '用户角色',
      name:'role',
      dataIndex: 'role',
      valueEnum: {
        admin: '管理员',
        user: '普通用户',
      },
    },
    {
      title: '操作',
      render:(_,item)=>{return [
        <Space size={"middle"}>
        <Button key={"edit"} onClick={() => openModal(item)} type="primary">Edit</Button>
        <Button key={"delete"} onClick={() => handleDelete(item.id)} type="primary" danger>Delete</Button>
      </Space>
      ]
      }
    },

  ];
  const questiontypes = [
    { value: 'objective', label: '客观题' },
    { value: 'subjective', label: '主观题' },
  ];
  return (
    <><ProTable
      headerTitle={formatMessage({
                                   id: 'pages.search.title',
                                   defaultMessage: '题目信息表',
                                 })}
  actionRef={actionRef}
  rowKey={record => {return record.id}}
  search={{
    labelWidth: 120,


  }}
  toolBarRender={() => [
    <Button
      type="primary"
    key="primary"
    onClick={() => openModal(null)}
>
  <PlusOutlined/> <FormattedMessage id="pages.searchTable.new" defaultMessage="New"/>
    </Button>,
]}
  request={getAllUsers}
  columns={columns}
  rowSelection={{
    onChange: (_, selectedRows) => {
      setSelectedRows(selectedRows);
    },
  }}/>{selectedRowsState?.length > 0 && (
  <FooterToolbar
  extra={
  <div>
  <FormattedMessage id="pages.searchTable.chosen" defaultMessage="Chosen" />{' '}
    <a style={{ fontWeight: 600 }}>{selectedRowsState.length}</a>{' '}
  <FormattedMessage id="pages.searchTable.item" defaultMessage="项" />
    &nbsp;&nbsp;
  </div>
}
>
  <Button
    onClick={async () => {
    await handleRemove(selectedRowsState);
    setSelectedRows([]);
    actionRef.current?.reloadAndRest?.();
  }}
  type={"primary"}
  danger
  >
  <FormattedMessage
    id="pages.searchTable.batchDeletion"
  defaultMessage="Batch deletion"
    />
    </Button>
  {/*  <Button type="primary" onClick={async () => {*/}
  {/*  setTakenExamModal(true);*/}
  {/*  console.log("选中行的内容: "+selectedRowsState);*/}
  {/*}}>*/}
  {/*<FormattedMessage*/}
  {/*  id="pages.searchTable.takenExam"*/}
  {/*defaultMessage="发布考试"*/}

  {/*  />*/}
  {/*  </Button>*/}
    </FooterToolbar>
)}


<Modal
  title={editingQuestion ? 'Edit Question' : 'Add Question'}
key={editingQuestion?.id}
open={modalVisible}
footer={null}
>
<UserForm initialValues={editingQuestion} onSubmit={handleCreateOrUpdate} onCancel={closeModal}/>
</Modal>
<Modal
title={"发布考试"}
key={"key123"}
open={takenExamModal}
footer={null}

>
<TakenExamForm valueId={selectedRowsState || {}} initialValues={editingQuestion} onSubmit={TakenExam} onCancel={closeTakenExam}/>
</Modal>
      </>
);
};

export default Questions;
