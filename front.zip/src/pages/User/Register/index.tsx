import React, { useEffect } from 'react';
import { Form, Input, Button, message, Card, Row, Col } from 'antd';
import {request} from "@umijs/max";
import {history} from "umi";
import './register.css';

const Register = () => {


  useEffect(() => {
    createStars(100);
    createShootingStars(5);
  }, []);

  const createStars = (numStars) => {
    const container = document.querySelector('.register-container');
    for (let i = 0; i < numStars; i++) {
      const star = document.createElement('div');
      star.className = 'star';
      star.style.top = `${Math.random() * 100}vh`;
      star.style.left = `${Math.random() * 100}vw`;
      star.style.animationDelay = `${Math.random() * 2}s`;
      container.appendChild(star);
    }
  };

  const createShootingStars = (numShootingStars) => {
    const container = document.querySelector('.register-container');
    for (let i = 0; i < numShootingStars; i++) {
      const shootingStar = document.createElement('div');
      shootingStar.className = 'shooting-star';
      shootingStar.style.top = `${Math.random() * 100}vh`;
      shootingStar.style.left = `${Math.random() * 100}vw`;
      shootingStar.style.animationDelay = `${Math.random() * 5}s`;
      container.appendChild(shootingStar);
    }
  };

  const onFinish = async (values) => {
    try {
      await request('/elect/user/register', {
        method: "Post",
        data:values,
      });
      message.success('User registered successfully');
      history.push('/user/login');
    } catch (error) {
      message.error('Registration failed');
    }
  };

  return (
    <div className="register-container">
      <Row justify="center" align="middle" className="full-height-row">
        <Col>
          <Card title="注册" bordered={false} headStyle={{ textAlign: 'center' }}>
          <Form onFinish={onFinish}>
        <Form.Item
          label="Username"
          name="username"
          rules={[{ required: true, message: '请输入用户名!' }]}
          style={{ marginBottom: '1.5rem' }}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Password"
          name="password"
          rules={[{ required: true, message: '请输入密码!' }]}
          style={{ marginBottom: '1.5rem' }}
        >
          <Input.Password />
        </Form.Item>

        <Form.Item
          label="Email"
          name="email"
          rules={[{ required: true, message: '请输入你的邮箱地址!' }]}
          style={{ marginBottom: '1.5rem' }}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="AvatarUrl"
          name="avatarUrl"
          rules={[{ required: true, message: '请添加你的头像地址!' }]}
          style={{ marginBottom: '1.5rem' }}
        >
          <Input />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Register;
