import React from 'react';
import {
  Layout,
  Menu,
  Breadcrumb,
  Card,
  Col,
  Row,
  Rate,
  Typography,
  Image
} from 'antd';
import { Link } from 'react-router-dom';

import 'antd/dist/reset.css';
import styles from './course.module.css';
const { Header, Content, Footer } = Layout;
const { Title } = Typography;

const courses = [
  {
    title: '课程1',
    imageUrl: 'https://xiuxiupro-material-center.meitudata.com/poster/8c98b88845630b4afc694e90ca81daa2.png',
    link: 'https://xiuxiupro-material-center.meitudata.com/poster/8c98b88845630b4afc694e90ca81daa2.png',
    description: '这是课程1的简介。',
    rating: 4.5,
  },
  {
    title: '课程2',
    imageUrl: 'https://tu.sioe.cn/gj/qiege/image.jpg',
    link: 'https://tu.sioe.cn/gj/qiege/image.jpg',
    description: '这是课程2的简介。',
    rating: 4.0,
  },
  // 更多课程...
];

const CoursePage = () => {
  return (
    <Layout>
      <Header style={{ position: 'fixed', zIndex: 1, width: '100%' }}>
        <div className="logo" />
        <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['1']}>
          <Menu.Item key="1">首页</Menu.Item>
          <Menu.Item key="2">课程</Menu.Item>
          <Menu.Item key="3">关于我们</Menu.Item>
        </Menu>
      </Header>
      <Content style={{ padding: '0 50px', marginTop: 64 }}>
        <Breadcrumb style={{ margin: '16px 0' }}>
          <Breadcrumb.Item>首页</Breadcrumb.Item>
          <Breadcrumb.Item>课程</Breadcrumb.Item>
        </Breadcrumb>
        <div style={{ background: '#fff', padding: 24, minHeight: 380 }}>
          <Title level={2} style={{ textAlign: 'center' }}>
            选课页面
          </Title>
          <Row gutter={[16, 16]} justify="center">
            {courses.map((course) => (
              <Col xs={24} sm={12} md={8} lg={6} key={course.title}>
                <Link to={{ pathname: course.link }} target="_blank">
                  <Card
                    hoverable
                    cover={<Image alt={course.title} src={course.imageUrl} className={styles.cardImage} style={{width: "100%",height:"140px"}}/>}
                    className={styles.card}
                  >
                    <Card.Meta
                      title={course.title}
                      description={course.description}
                    />
                    <Rate allowHalf defaultValue={course.rating} className={styles.cardRating} />
                  </Card>
                </Link>
              </Col>
            ))}
          </Row>
        </div>
      </Content>
      <Footer style={{ textAlign: 'center' }}>Ant Design ©2018 Created by Ant UED</Footer>
    </Layout>
  );
};

export default CoursePage;
