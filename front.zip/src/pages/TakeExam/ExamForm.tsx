import React from 'react';
import { Button, Form, Radio, Input } from 'antd';
import { QuestionType } from '@/constants/questionType';

const ExamForm: React.FC<{
  questions: any[];
  onSubmit: (answers: any[]) => void;
}> = ({ questions, onSubmit }) => {
  const [form] = Form.useForm();

  const handleSubmit = () => {
    const values = form.getFieldsValue();
    onSubmit(Object.entries(values).map(([key, value]) => ({ questionId: key, answer: value })));
  };

  return (
    <Form form={form} onFinish={handleSubmit} layout="vertical">
      {questions?.map((question: any, index: number) => (
        <Form.Item key={question.id} label={`${index + 1}. ${question.text}`} name={question.id}>
          {question.type === QuestionType.Objective ? (
            <Radio.Group>
              {question.options.map((option: any) => (
                <Radio key={option.id} value={option.id}>
                  {option.text}
                </Radio>
              ))}
            </Radio.Group>
          ) : (
            <Input.TextArea />
          )}
        </Form.Item>
      ))}
      <Form.Item>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
  );
};

export default ExamForm;
