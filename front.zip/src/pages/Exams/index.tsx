import React, { useEffect, useState } from 'react';
import {Button, Card, DatePickerProps, List, message, Modal, Space} from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import ExamForm from './ExamForm';
import {getExams, deleteExam, saveExam, updateExam,checkIfUserHasTakenExam} from '@/services/exams/exam';
import {RangePickerProps} from "antd/es/date-picker";
import {string} from "prop-types";
import {history} from "umi";


import { useAccess, Access } from 'umi';
import {Link } from "react-router-dom";
const Exams: React.FC = () => {
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingExam, setEditingExam] = useState(null);

  const [userExamStatus, setUserExamStatus] = useState({});
  const access = useAccess();
  useEffect(() => {
    const checkUserExamStatus = async () => {
      const response = await checkIfUserHasTakenExam();
      console.log(JSON.stringify(response)+"是否参加");
      setUserExamStatus(response);
    };
    checkUserExamStatus();
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const response = await getExams();
    setExams(response);
    setLoading(false);
  };

  const handleCreateOrUpdate = async (values: any) => {
    await updateExam(values);
    setModalVisible(false);
    setEditingExam(null)
    fetchData();
  };

  const handleDelete = async (id: number) => {
    await deleteExam(id);
    message.success('Exam deleted successfully');
    fetchData();
  };

  const openModal = (exam: any) => {
    setEditingExam(null);
    setEditingExam(exam);
    setModalVisible(true);
  };

  const closeModal = () => {
    setEditingExam(null);
    setModalVisible(false);
  };




  return (
    <Card
      title="考试信息"
      extra={
        <Link to={`/examResults/0`}><Button type="primary">查看考试结果</Button></Link>
      }
    >
      <List
        loading={loading}
        dataSource={exams}
        renderItem={(item: any) => (
          <List.Item
            actions={[
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Access accessible={access.canAdmin}>
                    <Button type="primary" onClick={() => openModal(item)}>Edit</Button>
                    <Button type="primary" danger onClick={() => handleDelete(item.id)}>Delete</Button>
                </Access>
                {
                  Date.now() > Date.parse(item.endTime) ? (
                    <Link to={`/answers/${sessionStorage.getItem("currentUserId")}/${item.id}`}><Button type="primary">查看考试结果</Button></Link>
                  ) : (
                    <Button type="primary" disabled={userExamStatus[item.id]} onClick={() => {
                      if (!userExamStatus[item.id]) {
                        history.push(`/examPages/${item.id}`);
                      }
                    }}>开始考试</Button>
                  )
                }
              </div>
            ]}
          >
            <List.Item.Meta  title={item.id} />
            <List.Item.Meta title={item.title} />
            <List.Item.Meta title={item.startTime} />
            <List.Item.Meta title={item.endTime} />
          </List.Item>
        )}
      />

      <Modal
        title={'编辑考试信息'}
        open={modalVisible}
        key={editingExam?.id}
        onCancel={closeModal}
        name="kry"
        footer={null}
      >

        <ExamForm initialValues={editingExam} onSubmit={handleCreateOrUpdate} />
      </Modal>
    </Card>
  );
};

export default Exams;
