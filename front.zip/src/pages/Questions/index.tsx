import React, {ReactText, useEffect, useRef, useState} from 'react';
import {Button, Card, Image, List, message, Modal, Progress, Select, Space, Tag} from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import QuestionForm from './QuestionForm';
import {getQuestions, deleteQuestion, saveQuestion, saveExam} from '@/services/exams/exam';
import {ActionType, FooterToolbar, ProList, ProTable} from "@ant-design/pro-components";
import {record} from "@umijs/utils/compiled/zod";
import {formatMessage, FormattedMessage} from "@@/exports";
import {rule} from "@/services/ant-design-pro/api";
import {request} from "@umijs/max";
import TakenExamForm from "@/pages/Questions/TakenExamForm";
import {values} from "lodash";


const handleRemove = async (selectedRows: API.RuleListItem[]) => {
  const hide = message.loading('正在删除');
  if (!selectedRows) return true;
  console.log({
    key: selectedRows.map((row) => row.id),
  })

  try {
    await request("/elect/questions/remove",{
        method:"post",
        data: {
          key: selectedRows.map((row) => row.id),
        }
      }
    );
    hide();
    message.success('成功删除!');
    return true;
  } catch (error) {
    hide();
    message.error('Delete failed, please try again');
    return false;
  }
};
const Questions: React.FC = () => {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [takenExamModal, setTakenExamModal] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState(null);

  const [selectedRowKeys, setSelectedRowKeys] = useState<ReactText[]>([]);
  const rowSelection = {
    selectedRowKeys,
    onChange: (keys: ReactText[]) => setSelectedRowKeys(keys),
  };

  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.RuleListItem>();
  const [selectedRowsState, setSelectedRows] = useState<API.RuleListItem[]>([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const response = await getQuestions();
    setQuestions(response);
    setLoading(false);
  };

  const handleCreateOrUpdate = async (values: any) => {
    console.log("values:"+values.imagePath)
    await saveQuestion(values);
    setEditingQuestion(null);
    setModalVisible(false);
    actionRef.current?.reload();
  };

  const TakenExam = async (values: any)=>{
    console.log("发布考试相关信息:"+values)
    await saveExam(values);
    setTakenExamModal(false)
    actionRef.current?.reload();
  }
  const handleDelete = async (id: number) => {
    await deleteQuestion(id);
    message.success('Question deleted successfully');
    fetchData();
    actionRef.current?.reload();
  };

  const openModal = (question: any) => {
    console.log("edit: "+JSON.stringify({...question}));
    setEditingQuestion(question);
    setModalVisible(true);
  };

  const closeModal = () => {
    setEditingQuestion(null);
    setModalVisible(false);
    actionRef.current?.reload();
  };

  const closeTakenExam = () => {
    setTakenExamModal(false);
    actionRef.current?.reload();
  };
  const columns =[
    {
      title: 'ID',
      name:'id',
      dataIndex: 'id',
    },
    {
      title: '题目内容',
      name:'text',
      dataIndex: 'text',
    },
    {
      title: '图片',
      name:'ImagePath',
      dataIndex: 'imagePath',
      render: (imageUrl) =>{
        return imageUrl!="-"?<Image width={100} src={'/elect/'+imageUrl} />:<></>
      },
    },
    {
      title: '类别',
      name:'category',
      dataIndex: 'category',
    },{
      title: '类型',
      name:'questionType',
      dataIndex: 'questionType',
      valueEnum: {
        objective: '客观题',
        subjective: '主观题',
      },
    },
    {
      title: '操作',
      dataIndex: 'questionType',
      render:(_,item)=>{return [
        <Space size={"middle"}>
          <Button key={"edit"} onClick={() => openModal(item)} type="primary">Edit</Button>
          <Button key={"delete"} onClick={() => handleDelete(item.id)} type="primary" danger>Delete</Button>
        </Space>
        ]
      }
    },

  ];
  const questiontypes = [
    { value: 'objective', label: '客观题' },
    { value: 'subjective', label: '主观题' },
  ];
  return (
    <><ProTable
      headerTitle={formatMessage({
        id: 'pages.search.title',
        defaultMessage: '题目信息表',
      })}
      actionRef={actionRef}
      rowKey={record => {return record.id}}
      search={{
        labelWidth: 120,


      }}
      toolBarRender={() => [
        <Button
          type="primary"
          key="primary"
          onClick={() => openModal(null)}
        >
          <PlusOutlined/> <FormattedMessage id="pages.searchTable.new" defaultMessage="New"/>
        </Button>,
      ]}
      request={getQuestions}
      columns={columns}
      rowSelection={{
        onChange: (_, selectedRows) => {
          setSelectedRows(selectedRows);
        },
      }}/>{selectedRowsState?.length > 0 && (
      <FooterToolbar
        extra={
          <div>
            <FormattedMessage id="pages.searchTable.chosen" defaultMessage="Chosen" />{' '}
            <a style={{ fontWeight: 600 }}>{selectedRowsState.length}</a>{' '}
            <FormattedMessage id="pages.searchTable.item" defaultMessage="项" />
            &nbsp;&nbsp;
          </div>
        }
      >
        <Button
          onClick={async () => {
            await handleRemove(selectedRowsState);
            setSelectedRows([]);
            actionRef.current?.reloadAndRest?.();
          }}
          type={"primary"}
          danger
        >
          <FormattedMessage
            id="pages.searchTable.batchDeletion"
            defaultMessage="Batch deletion"
          />
        </Button>
        <Button type="primary" onClick={async () => {
          setTakenExamModal(true);
          console.log("选中行的内容: "+selectedRowsState);
        }}>
          <FormattedMessage
            id="pages.searchTable.takenExam"
            defaultMessage="发布考试"

          />
        </Button>
      </FooterToolbar>
    )}


      <Modal
      title={editingQuestion ? 'Edit Question' : 'Add Question'}
      key={editingQuestion?.id}
      open={modalVisible}
      footer={null}
    >
      <QuestionForm initialValues={editingQuestion} onSubmit={handleCreateOrUpdate} onCancel={closeModal}/>
    </Modal>
      <Modal
        title={"发布考试"}
        key={"key123"}
        open={takenExamModal}
        footer={null}

      >
        <TakenExamForm valueId={selectedRowsState || {}} initialValues={editingQuestion} onSubmit={TakenExam} onCancel={closeTakenExam}/>
      </Modal>

    </>
  );
};

export default Questions;
