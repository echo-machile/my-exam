import React, {useState} from 'react';
import {Button, Form, Input, Select, Upload, Image, message, Space, Checkbox} from 'antd';
import {MinusCircleOutlined, PlusOutlined, UploadOutlined} from '@ant-design/icons';
import { QuestionType } from '@/constants/questionType';
import {val} from "@umijs/utils/compiled/cheerio/lib/api/attributes";
import {usage} from "@umijs/bundler-webpack/compiled/autoprefixer/browserslist";

const { Option } = Select;

const QuestionForm: React.FC<{ initialValues?: any; onSubmit: (values: any) => void;onCancel: (values: any) => void }> = ({
                                                                                            initialValues,
                                                                                            onSubmit,
  onCancel
                                                                                          }) => {
  const [form] = Form.useForm();
  const [img,setImg] = useState(null);
  const [img2,setImg2] = useState(null);

  console.log("初始值:"+initialValues?.imagePath+img)
  const handleSubmit = (values: any) => {
    values.imagePath = img?img:initialValues?.imagePath;
    // values.options.imagePath = img2;
    onSubmit(values);
    form.resetFields();
  };

  const handleUpload = (file: any) => {
    // You can use a third-party library like 'axios' to send the file to your backend
    // For example:
    // const formData = new FormData();
    // formData.append('file', file);
    // axios.post('/api/upload', formData);

    // Simulating a successful upload:
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve("https://example.com/your-uploaded-image-url.jpg");
      }, 1000);
    });
  };

  return (
    <Form
      form={form}
      initialValues={initialValues?initialValues:{ questionType:"objective"}}
      onFinish={handleSubmit}
      layout="vertical"
    >
      {/* ... other form items ... */}
      <Form.Item
        label="ID"
        name="id"
        // extra="填写题目内容"
      >
        <Input disabled></Input>
      </Form.Item>
      <Form.Item
        label="内容"
        name="text"
        rules={[{ required: true, message: '请输入题目内容!' }]}
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入题目内容"}></Input>
      </Form.Item>

      <Form.Item
        label="Image"
        name="image"
        valuePropName="fileList"
        getValueFromEvent={(e) => (Array.isArray(e.fileList) ? e.fileList : [])}
        extra="Select an image to upload"
      >

        <Upload
          //customRequest={({ file }) => handleUpload(file)}
          accept="image/*"
          showUploadList={false}
          action="/elect/file/upload"
          headers={{
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            token: sessionStorage.getItem("token")
          }}

          onChange={(info) => {
            if (info.file.status === 'done') {
              console.log(info.file.response)
              setImg(info.file.response)
              message.success(`${info.file.name} 文件上传成功`);
            } else if (info.file.status === 'error') {
              message.error(`${info.file.name} 文件上传失败`);
            }
          }}
        >
          <Button icon={<UploadOutlined />}>Upload Image</Button>
        </Upload>
        <Image
          width={200}
          // defaultValue={initialValues?.imagePath}

          src={img?'/elect'+img:'elect'+initialValues?.imagePath}
        />
      </Form.Item>
      <Form.Item
        label="类别:"
        name="category"
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入题目类别"}></Input>
      </Form.Item>
      <Form.Item
        label="类型:"
        name="questionType"
        // extra="填写题目内容"
      >
        <Select defaultValue={"subjective"} showSearch>
          <Option value={"subjective"}>主观题</Option>
          <Option value={"objective"}>客观题</Option>
        </Select>
      </Form.Item>
      <Form.List name="options">
        {(fields, { add, remove }) => (
          <>
            {fields.map((field,index) => (
              <Space key={field.key} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                <Form.Item
                  {...field}
                  name={[field.name, 'text']}
                  key={field.key}
                  rules={[{  message: '请输入选项内容！' }]}
                >
                  <Input placeholder="选项内容" />
                </Form.Item>
                <Form.Item
                  {...field}
                  name={[field.name, 'imagePath']}
                  key={[field.key,'imagePath']}
                  >
                  <Upload
                    //customRequest={({ file }) => handleUpload(file)}
                    accept="image/*"
                    showUploadList={true}
                    action="/elect/file/optionsImage/upload"
                    headers={{
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                      token: sessionStorage.getItem("token")
                    }}

                    onChange={(info) => {
                      if (info.file.status === 'done') {
                        console.log(info.file.response);
                        setImg2(info.file.response); // 不再需要这一行
                        message.success(`${info.file.name} 文件上传成功`);

                        // 获取当前表单的值
                        const currentValues = form.getFieldsValue();

                        // 更新当前选项的 imagePath 值
                        // @ts-ignore
                        if (currentValues.options && currentValues.options[index]) {
                          // 更新当前选项的 imagePath 值
                          currentValues.options[index].imagePath = info.file.response;

                          // 设置更新后的表单值
                          form.setFieldsValue(currentValues);
                        } else {
                          console.error('Unable to set imagePath for the current option');
                        }
                      } else if (info.file.status === 'error') {
                        message.error(`${info.file.name} 文件上传失败`);
                      }
                    }}
                  >
                    <Button icon={<UploadOutlined />}>Upload Image</Button>
                  </Upload>
                  {
                    initialValues?.options[index]?.imagePath&&<Image
                      width={20}
                      src={img2?'/elect'+img2:'/elect'+initialValues?.options[index]?.imagePath}
                    />
                  }
                </Form.Item>

                <Form.Item
                  {...field}
                  name={[field.name, 'correct']}
                  key={[field.key, 'correct']}
                  valuePropName="checked"
                >
                  <Checkbox>正确答案</Checkbox>
                </Form.Item>
                <MinusCircleOutlined onClick={() => remove(field.name)} />
              </Space>
            ))}
            <Form.Item>
              <Button
                type="dashed"
                onClick={() => {
                  add({
                    text: "",
                    imagePath: "",
                    correct: false
                  });
                }}
                block
                icon={<PlusOutlined />}
              >
                添加选项
              </Button>
            </Form.Item>
          </>
        )}
      </Form.List>
      <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit">
          确认
        </Button>
        <Button
          htmlType="button"
          style={{ marginLeft: '1rem' }}
          onClick={onCancel}
        >
          取消
        </Button>
      </Form.Item>

      {/* ... other form items ... */}
    </Form>
  );
};

export default QuestionForm;
