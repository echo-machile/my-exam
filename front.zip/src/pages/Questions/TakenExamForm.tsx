import React, {useState} from 'react';
import {Button, Form, Input, Select, Upload, Image, message, Space, DatePicker, DatePickerProps} from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import { QuestionType } from '@/constants/questionType';
import {val} from "@umijs/utils/compiled/cheerio/lib/api/attributes";
import {usage} from "@umijs/bundler-webpack/compiled/autoprefixer/browserslist";
import {RangePickerProps} from "antd/es/date-picker";
import {string} from "prop-types";

const { Option } = Select;

const { RangePicker } = DatePicker;
const TakenExamForm: React.FC<{ valueId?:any;initialValues?: any; onSubmit: (values: any) => void;onCancel: (values: any) => void }> = ({
                                                                                                                            valueId,initialValues, onSubmit,
                                                                                                                            onCancel
                                                                                                                          }) => {

  const [form] = Form.useForm();
  const [img,setImg] = useState(null);
  const [date,setDate] = useState([]);
  console.log("初始值:"+initialValues?.imagePath+img)
  const handleSubmit = (values: any) => {
    values.startTime = date[0];
    values.endTime = date[1];
    values.questions = valueId;
    console.log("kkk"+values.endTime)
    onSubmit(values);
    message.success("发布成功!")
  };

  const handleUpload = (file: any) => {
    // You can use a third-party library like 'axios' to send the file to your backend
    // For example:
    // const formData = new FormData();
    // formData.append('file', file);
    // axios.post('/api/upload', formData);

    // Simulating a successful upload:
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve("https://example.com/your-uploaded-image-url.jpg");
      }, 1000);
    });
  };

  const onChange = (
    value: DatePickerProps['value'] | RangePickerProps['value'],
    dateString: [string, string] | string,
  ) => {
    console.log('Selected Time: ', value);
    console.log('Formatted Selected Time: ', dateString);
    setDate(dateString);
  };

  const onOk = (value: DatePickerProps['value'] | RangePickerProps['value']) => {
    console.log('onOk: ', value);
  };

  return (
    <Form
      form={form}
      initialValues={initialValues?initialValues:{ questionType:"objective"}}
      onFinish={handleSubmit}
      layout="vertical"
    >
      {/* ... other form items ... */}
      <Form.Item
        label="标题"
        name="title"
        rules={[{ required: true, message: '请输入实训标题!' }]}
        // extra="填写题目内容"
      >
        <Input placeholder={"请输入题目内容"}></Input>
      </Form.Item>
      <Space direction="vertical" size={12}>
        <RangePicker
          name={"time"}
          showTime={{ format: 'HH:mm' }}
          format="YYYY-MM-DD HH:mm"
          onChange={onChange}
          onOk={onOk}
        />
      </Space>

      <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit">
          确认
        </Button>
        <Button
          htmlType="button"
          style={{ marginLeft: '1rem' }}
          onClick={onCancel}
        >
          取消
        </Button>
      </Form.Item>

      {/* ... other form items ... */}
    </Form>
  );
};

export default TakenExamForm;
