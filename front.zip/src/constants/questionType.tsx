export enum QuestionType {
  OBJECTIVE = 'objective',
  SUBJECTIVE = 'subjective',
}
