import {request} from "@umijs/max";


interface GradedScore {
  userAnswerId: number;
  score: number;
}

export async function getExam(examId: string) {
  return request(`/elect/exams/${examId}`, {
    method: 'GET',
  });
}

export async function submitExam(examId: string, answers: any[]) {

  return request(`/elect/exams/${examId}/submit`, {
    method: 'POST',
    data: answers,
    headers: {
      'Content-Type': 'application/json',
    },
  });
}


// 获取考试列表
export async function getExams() {
  return request('/elect/exams', {
    method: 'GET',
  });
}

// 删除考试
export async function deleteExam(examId: string) {
  return request(`/elect/exams/${examId}`, {
    method: 'DELETE',
  });
}

// 保存考试
export async function saveExam(exam: any) {
  return request('/elect/exams', {
    method: 'POST',
    data: exam,
  });
}

export async function updateExam(exam: any) {
  return request('/elect/exams/updateExams', {
    method: 'POST',
    data: exam,
  });
}

// 获取考试成绩
export async function getExamResults(examId: string) {
  return request(`/elect/examRecords/${sessionStorage.getItem("currentUserId")}/${examId}/results`, {
    method: 'GET',
  });
}
export async function getAllExamResults() {
  return request(`/elect/examRecords/${sessionStorage.getItem("currentUserId")}/results`, {
    method: 'GET',
  });
}
// 获取考试答案
export async function getUserAnswers(userId:number,examId:number) {
  return request(`/elect/answers/${userId}/${examId}`, {
    method: 'GET',
  });
}



// 批改考试
export async function correctExam(examRecordId: string, correctedAnswers: any[]) {
  return request(`/api/examRecords/${examRecordId}/correct`, {
    method: 'POST',
    data: correctedAnswers,
  });
}



export async function getQuestions(params) {
  return request('/elect/questions', {
    method: 'GET',
    params
  });
}


export async function getAllUsers(params) {
  return request('/elect/admin/users', {
    method: 'GET',
    params
  });
}

export async function deleteQuestion(id: number) {
  return request(`/elect/questions/${id}`, {
    method: 'DELETE',
  });
}


export async function deleteUser(id: number) {
  return request(`/elect/admin/${id}`, {
    method: 'DELETE',
  });
}

export async function saveQuestion(data: any) {
  return data.id
    ? request(`/elect/questions/${data.id}`, {
      method: 'PUT',
      data,
    })
    : request('/elect/questions', {
      method: 'POST',
      data,
    });
}

export async function saveUsers(data: any) {
  return data.id
    ? request(`/elect/admin/users/${data.id}`, {
      method: 'PUT',
      data,
    })
    : request('/elect/admin/add', {
      method: 'POST',
      data,
    });
}



export async function submitGradedScores(gradedScores: GradedScore[]) {
  return request(`/elect/answers/gradedScores`, {
    method: 'POST',
    data: gradedScores,
  });
}

export async function checkIfUserHasTakenExam(){
  return request(`/elect/exams/records/checkIfUserHasTakenExam/${sessionStorage.getItem("currentUserId")}`,{
    method:'Get',
  })
}
