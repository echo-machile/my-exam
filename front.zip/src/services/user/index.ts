// src/services/user.js

import { request } from "@umijs/max";


export async function login(data) {
  return request('/api/user/login', {
    method: 'POST',
    data,
  });
}
