package com.elect.electexam.Common.Security;

import com.elect.electexam.Common.Constant.JwtConstant;
import com.elect.electexam.Enitity.User;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.Enitity.checkResult;
import com.elect.electexam.untils.JwtUtils;
import com.elect.electexam.untils.StringUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

public class jwtAuthFilter  extends BasicAuthenticationFilter {

    @Autowired
    private UserService sysUserService;

    @Autowired
    private MyUserDetailServiceImpl myUserDetailService;


    private static final String[] URL_WHITELiST ={
            "/user/login",
            "/logout",
            "/captcha",
            "/password",
            "/images/**",

    };
    public jwtAuthFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {



        String token = request.getHeader("token");

        System.out.println(token);
        System.out.println("请求url: "+request.getRequestURI());


        //token是空或者url在白名单放行
        if(StringUtil.isEmpty(token) || new ArrayList<String>(Arrays.asList(URL_WHITELiST)).contains(request.getRequestURI())){
            chain.doFilter(request,response);
            System.out.println(request);
            System.out.println(response);
            return ;
        }


        checkResult check = JwtUtils.validateJWT(token);
        if(!check.isSuccess()){
            switch(check.getErrCode()){
                case JwtConstant.JWT_ERRCODE_NULL: throw new JwtException("token不存在");
                case JwtConstant.JWT_ERRCODE_FAIL: throw new JwtException("token验证不通过");
                case JwtConstant.JWT_ERRCODE_EXPIRE: throw new JwtException("token过期");
            }
        }

        Claims claims = JwtUtils.parseJWT(token);
        String userName = claims.getSubject();
        Optional<User> admin = sysUserService.getByUserName(userName);

        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userName,null,myUserDetailService.getAuthority(admin.get().getId()));
        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
        chain.doFilter(request,response);
    }

    public jwtAuthFilter(AuthenticationManager authenticationManager, AuthenticationEntryPoint authenticationEntryPoint) {
        super(authenticationManager, authenticationEntryPoint);
    }
}
