package com.elect.electexam.Common.Security;

import com.elect.electexam.Service.UserService;
import com.elect.electexam.Common.Exception.UserCountLockException;
import com.elect.electexam.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import  org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;



import java.util.List;
import java.util.Optional;

@Service
public class MyUserDetailServiceImpl implements UserDetailsService {

    @Autowired
    UserService sysUserService;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        System.out.println(username+"????");
        com.elect.electexam.Enitity.User admin = sysUserService.getByUserName(username).get();

        System.out.println(admin.getUsername());
        System.out.println("这是什么？");
        if(admin==null){
            throw new UsernameNotFoundException("用户名或者密码错误!");
        }else if ("1".equals(admin.getUsername())){//这里设置一个假的，此处可以代表是否处于封禁状态
            try {
                throw new UserCountLockException("用户账号被封禁!");
            } catch (UserCountLockException e) {
                throw new RuntimeException(e);
            }
        }

        System.out.println(admin.getUsername());
        System.out.println(admin.getPassword());

        return new User(admin.getUsername(), new BCryptPasswordEncoder().encode(admin.getPassword()), getAuthority(admin.getId()));
    }

    public List<GrantedAuthority> getAuthority(long userId) {
        String authority = sysUserService.getAuthorityInfo(userId);
        //格式:ROLE_admin,ROLE_common,system:user:resetPwd,system:role:delete,sytem:user:list,system:menu:query
        return AuthorityUtils.commaSeparatedStringToAuthorityList(authority);
    }
}
