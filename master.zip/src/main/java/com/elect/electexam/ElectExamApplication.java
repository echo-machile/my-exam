package com.elect.electexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(ElectExamApplication.class, args);
    }

}
