package com.elect.electexam.Jpa;

import com.elect.electexam.Enitity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ExamRecordRepository extends JpaRepository<ExamRecord, Long> {

    List<ExamRecord> findByUserAndExam(User user, Exam exam);
    List<ExamRecord> findByUserId(Long userId);
    List<ExamRecord> findByExamId(Long examId);
    List<ExamRecord> findByUser_IdAndExam_Id(Long user_id, Long exam_id);

    @Query(value = "SELECT exam_records.id, users.username AS username, exams.title AS title,score \n" +
            "FROM exam_records \n" +
            "JOIN users ON exam_records.user_id = users.id \n" +
            "JOIN exams ON exam_records.exam_id = exams.id \n" +
            "WHERE exam_records.user_id = ?1 AND exam_records.exam_id = ?2",nativeQuery = true)
    List<Object[]> findByUserIdAndExamId(Long userId, Long examId);
}
