package com.elect.electexam.Jpa;

import com.elect.electexam.Enitity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;

@Repository
public interface ExamRepository extends JpaRepository<Exam, Long> {

    @Transactional
    @Modifying
    @Query(value = "update exams set title=?1,start_time=?2,end_time=?3 where id = ?4",nativeQuery = true)
    void updateMsg( String title, Timestamp startTime, Timestamp endTime,Integer id);
}
