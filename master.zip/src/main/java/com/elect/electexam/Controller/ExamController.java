package com.elect.electexam.Controller;

import com.elect.electexam.Enitity.*;
import com.elect.electexam.Service.ExamRecordService;
import com.elect.electexam.Service.ExamService;
import com.elect.electexam.Service.QuestionService;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.untils.Res;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/exams")
public class ExamController {
    @Autowired
    private ExamService examService;


    @Autowired
    private ExamRecordService examRecordService;

    @Autowired
    private UserService userService;

    @Autowired
    private QuestionService questionService;

    @GetMapping
    public ResponseEntity<List<Exam>> getAllExams() {
        List<Exam> exams = examService.findAll();
        return ResponseEntity.ok(exams);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Exam> getExamById(@PathVariable Long id) {
        Exam exam = examService.findById(id);
        if (exam == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(exam);
    }

    @PostMapping
    public ResponseEntity<Exam> createExam(@RequestBody Exam exam) {
        System.out.println(exam);
        Exam savedExam = examService.save(exam);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedExam);
    }

//    @PostMapping("/getQuestions")
//    public ResponseEntity<Exam> getQuestionsByExamId(@RequestBody Map<String,String> map) {
//        System.out.println(map.get("id"));
//        Integer examId = Integer.valueOf(map.get("id"));
//        Exam savedExam = questionService.findById();
//        return ResponseEntity.status(HttpStatus.CREATED).body(savedExam);
//    }

    @PostMapping("/updateExams")
    public Res createExam(@RequestBody Map<String,String> exam) throws ParseException {
        String startTimeStr = exam.get("startTime");
        String endTimeStr = exam.get("endTime");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Timestamp startTime = new Timestamp(dateFormat.parse(startTimeStr).getTime());
        Timestamp endTime = new Timestamp(dateFormat.parse(endTimeStr).getTime());
        String title = exam.get("title");
        Integer id  = Integer.valueOf(exam.get("id"));
        if(examService.updateExams(id,title,startTime,endTime)){
            return Res.ok("更新成功");
        };
        return Res.error("更新失败");
    }

    @PutMapping("/{id}")
    public ResponseEntity<Exam> updateExam(@PathVariable Long id, @RequestBody Exam exam) {
        Exam existingExam = examService.findById(id);
        if (existingExam == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        exam.setId(id);
        Exam updatedExam = examService.save(exam);
        return ResponseEntity.ok(updatedExam);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteExam(@PathVariable Long id) {
        Exam existingExam = examService.findById(id);
        if (existingExam == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        examService.deleteById(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping("/{examId}/submit")
    public ExamRecord submitAnswers(
            @PathVariable Long examId,
            @RequestBody List<UserAnswer>userAnswers,
            HttpServletRequest request) {

        for (UserAnswer userAnswer:userAnswers){
            userAnswer.setUser(userService.findById(userAnswer.getUserId()).get());
            userAnswer.setQuestion(questionService.findById(userAnswer.getQuestionId()));
            userAnswer.setExam(examService.findById(userAnswer.getExamId()));
        }
        System.out.println(userAnswers);
//        System.out.println("用户: "+user);
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        Optional<User> user = userService.getByUserName(authentication.getPrincipal().toString());
        Object principal = authentication.getPrincipal();
        if (principal instanceof User) {
            user = Optional.of((User) principal);
            System.out.println("用户名称:1 "+user);
        } else if (principal instanceof UserDetails) {
            String username = ((UserDetails) principal).getUsername();
            System.out.println("用户名称: "+username);
            user = userService.getByUserName(username);
        }
        return examService.submitAnswers(examId, userAnswers, user.get());
    }



    @GetMapping("/records/{recordId}")
    public ExamRecord getExamRecord(@PathVariable Long recordId) {
        return examService.getExamRecord(recordId);
    }

    @PostMapping("/records/{recordId}/correct")
    public ExamRecord correctExam(
            @PathVariable Long recordId,
            @RequestBody List<UserAnswer> userAnswers) {
        return examService.correctExam(recordId, userAnswers);
    }

    @GetMapping("/records/getRecords")
    public List<ExamRecord> getExamRecords() {
        return examRecordService.findAll();
    }




}
