package com.elect.electexam.Controller;


import com.elect.electexam.Enitity.*;
import com.elect.electexam.Jpa.ExamRecordRepository;
import com.elect.electexam.Jpa.ExamRepository;
import com.elect.electexam.Service.ExamRecordService;
import com.elect.electexam.Service.ExamService;
import com.elect.electexam.Service.UserAnswersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/answers")
public class UserAnswersController {



    @Autowired
    UserAnswersService userAnswersService;

    @Autowired
    ExamRecordService examRecordService;


    @Autowired
    ExamRecordRepository examRecordRepository;





    @GetMapping("/{userid}/{examid}")
    public ResponseEntity<List<UserAnswer>> getUserAnsersByExamIdAndUserId(@PathVariable Long userid,@PathVariable Long examid) {

        System.out.println("用户id: "+userid+"考试id: "+examid);
        List<UserAnswer> userAnswers = userAnswersService.findByUserIdAndExamId(userid,examid);

        for (UserAnswer userAnswer : userAnswers) {
            userAnswer.getUser().getUsername(); // 只是一个示例，您可以根据需要调用其他方法或访问其他属性
            userAnswer.getQuestion().getText();
            userAnswer.getExam().getTitle();
        }
        return ResponseEntity.ok(userAnswers);
    }



    @PostMapping("/gradedScores")
    public void submitGradedScores(@RequestBody List<GradedScore> gradedScores) {
        System.out.println("打分情况:"+gradedScores);
        int score = 0;
        for (GradedScore gradedScore : gradedScores) {
            UserAnswer userAnswer = userAnswersService.findById(gradedScore.getUserAnswerId())
                    .orElseThrow(() -> new IllegalArgumentException("Invalid user answer id"));

            userAnswer.setScore(gradedScore.getScore());
            userAnswersService.save(userAnswer);
            score+=gradedScore.getScore();
        }

        List<UserAnswer> userAnswers = userAnswersService.findByUserIdAndExamId(gradedScores.get(0).getUserId(),gradedScores.get(0).getExamId());
        for(UserAnswer userAnswer:userAnswers){
            score += userAnswer.getScore();
        }
        System.out.println("总分数"+score);
       List<ExamRecord> examRecords= examRecordRepository.findByUser_IdAndExam_Id(gradedScores.get(0).getUserId(),gradedScores.get(0).getExamId());

        for (ExamRecord examRecord:examRecords){
            examRecord.setScore(score);
            examRecordRepository.save(examRecord);
        }
    }

}
