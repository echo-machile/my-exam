package com.elect.electexam.Controller;

import com.elect.electexam.Enitity.Exam;
import com.elect.electexam.Service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/quiz")
public class QuizController {
    @Autowired
    private ExamService examService;

    @GetMapping("/exams")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getExams() {
        List<Exam> exams = examService.findAll();
        return ResponseEntity.ok(exams);
    }
}
