package com.elect.electexam.Controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@RestController
@RequestMapping("/file")
public class FileUploadController {


    @Value("${file.storage.path}")
    private static  String UPLOAD_DIR = "/Users/chenluo/uploads/";
    private static  String UPLOAD_DIR_option = "/Users/chenluo/uploads/options/";

    @PostMapping("/upload")
    public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
        System.out.println("这里执行:"+file);
        try {
            // 生成文件名
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

            System.out.println("UPLOAD_DIR: " + UPLOAD_DIR);

            // 获取文件的存储路径
            Path path = Paths.get(UPLOAD_DIR + fileName);

            // 打印 path 的值
            System.out.println("path: " + path);
            // 创建目录
            Files.createDirectories(path.getParent());
            // 保存文件
            Files.copy(file.getInputStream(), path);
            // 返回文件的 URL
            String fileUrl = "/uploads/" + fileName;
            return new ResponseEntity<>(fileUrl, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping("/optionsImage/upload")
    public ResponseEntity<String> handleFileOPtionImageUpload(@RequestParam("file") MultipartFile file) {
        System.out.println("这里执行选项文件:"+file);
        try {
            // 生成文件名
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

            System.out.println("UPLOAD_DIR: " + UPLOAD_DIR_option);

            // 获取文件的存储路径
            Path path = Paths.get(UPLOAD_DIR_option + fileName);

            // 打印 path 的值
            System.out.println("path: " + path);
            // 创建目录
            Files.createDirectories(path.getParent());
            // 保存文件
            Files.copy(file.getInputStream(), path);
            // 返回文件的 URL
            String fileUrl = "/uploads/options/" + fileName;
            return new ResponseEntity<>(fileUrl, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

