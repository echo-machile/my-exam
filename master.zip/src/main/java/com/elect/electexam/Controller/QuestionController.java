package com.elect.electexam.Controller;

import com.elect.electexam.Enitity.Option;
import com.elect.electexam.Enitity.Question;
import com.elect.electexam.Enitity.QuestionType;
import com.elect.electexam.Service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/questions")
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    @RequestMapping
    public ResponseEntity<Map<String,Object>> getAllQuestions(@RequestParam(required = false) Integer current,
                                                              @RequestParam(required = false) Integer pageSize,
                                                              @RequestParam(required = false) Long id,
                                                              @RequestParam(required = false) String text,
                                                              @RequestParam(required = false) String imagePath,
                                                              @RequestParam(required = false) String category,
                                                              @RequestParam(required = false) QuestionType questionType) {
        Pageable pageable = PageRequest.of(current != null ? current - 1 : 0, pageSize != null ? pageSize : 10);
        Page<Question> questionsPage = questionService.findFilteredQuestions(id, text, imagePath, category, questionType, pageable);
        //List<Question> questions = questionService.findAll();
        Map<String,Object> map = new HashMap<>();
        map.put("data",questionsPage.getContent());
        map.put("success",true);
        map.put("total",questionsPage.getTotalElements());
        return ResponseEntity.ok(map);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Question> getQuestionById(@PathVariable Long id) {
        Question question = questionService.findById(id);
        if (question == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(question);
    }

//    @PostMapping
//    public ResponseEntity<Question> createQuestion(@RequestBody Question question) {
//        System.out.println(question);
//        Question savedQuestion = questionService.save(question);
//        return ResponseEntity.status(HttpStatus.CREATED).body(savedQuestion);
//    }

    // QuestionController.java
    @PostMapping
    public ResponseEntity<Question> createOrUpdateQuestion(@RequestBody Question question) {
        for (Option option : question.getOptions()) {
            // 根据具体情况设置 correct 字段值，这里只是一个示例
            if(option.getCorrect() == null){
                option.setCorrect(false);
            }

        }
        return ResponseEntity.ok(questionService.saveQuestion(question));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Question> updateQuestion(@PathVariable Long id, @RequestBody Question question) {
        Question existingQuestion = questionService.findById(id);
        System.out.println(existingQuestion);
        if (existingQuestion == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        questionService.deleteById(id);
        System.out.println("删除成功！");
        question.setId(id);
        Question updatedQuestion = questionService.save(question);

        System.out.println(updatedQuestion);
        return ResponseEntity.ok(updatedQuestion);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteQuestion(@PathVariable Long id) {
        Question existingQuestion = questionService.findById(id);
        if (existingQuestion == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        questionService.deleteById(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping("/remove")
    public void deleteQuestions(@RequestBody Map<String,List<Long>> map){
        System.out.println(map);
        for (Long id : map.get("key")) {
            questionService.deleteById(id);
        }
    }
}
