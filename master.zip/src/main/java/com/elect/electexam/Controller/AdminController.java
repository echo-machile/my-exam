package com.elect.electexam.Controller;

import com.elect.electexam.Enitity.User;
import com.elect.electexam.Service.ExamService;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.Service.lmp.UserServicelmp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private UserServicelmp userService;

    @Autowired
    private ExamService examService;

    @GetMapping("/users")
    public ResponseEntity<List<User>> getUsers() {
        List<User> users = userService.findAll();
        return ResponseEntity.ok(users);
    }

    // ... 其他管理员相关的 API 端点

}
