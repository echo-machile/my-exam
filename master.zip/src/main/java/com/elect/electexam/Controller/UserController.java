package com.elect.electexam.Controller;

import com.elect.electexam.Enitity.LoginRequest;
import com.elect.electexam.Enitity.RegistrationRequest;
import com.elect.electexam.Enitity.RoleType;
import com.elect.electexam.Enitity.User;
import com.elect.electexam.Service.UserService;
import com.elect.electexam.untils.Res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elect.electexam.untils.JwtUtils;

import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

//    @Autowired
//    private JwtUtil jwtUtil;

    // ... other methods

    @RequestMapping("/currentUser")
    public Res login(@RequestBody(required = false) Map<String,String> map) {
        System.out.println("这里执行类");
        String Id = map.get("id");
        System.out.println(Id);

        Optional<User> user = userService.findById(Long.valueOf(Id));
        System.out.println(user);
        return Res.ok(user.get());
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegistrationRequest request) {
        try {
            User user = new User();
            user.setUsername(request.getUsername());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setEmail(request.getEmail());
            user.setRole(RoleType.user);
            userService.save(user);
            return ResponseEntity.ok("User registered successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Registration failed");
        }
    }
}
