package com.elect.electexam.Service;

import com.elect.electexam.Enitity.UserAnswer;

import java.util.List;
import java.util.Optional;

public interface UserAnswersService {

    List<UserAnswer> findByUserIdAndExamId(Long userId, Long examId);
    Optional<UserAnswer> findById(Long userAnswerId);
    UserAnswer save(UserAnswer userAnswer);


}
