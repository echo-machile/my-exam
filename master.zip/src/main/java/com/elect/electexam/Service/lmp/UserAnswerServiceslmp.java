package com.elect.electexam.Service.lmp;


import com.elect.electexam.Enitity.UserAnswer;
import com.elect.electexam.Jpa.UserAnswerRepository;
import com.elect.electexam.Service.UserAnswersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserAnswerServiceslmp implements UserAnswersService {

    @Autowired
    private UserAnswerRepository userAnswerRepository;
    @Override
    public List<UserAnswer> findByUserIdAndExamId(Long userId, Long examId){
        return userAnswerRepository.findByUser_IdAndExam_Id(userId, examId);
    }

    @Override
    public Optional<UserAnswer> findById(Long userAnswerId) {
        return userAnswerRepository.findById(userAnswerId);
    }

    @Override
    public UserAnswer save(UserAnswer userAnswer) {
        return userAnswerRepository.save(userAnswer);
    }

}
