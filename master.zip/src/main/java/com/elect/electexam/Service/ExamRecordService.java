package com.elect.electexam.Service;

import com.elect.electexam.Enitity.ExamRecord;
import com.elect.electexam.Enitity.ExamRecordInfo;

import java.util.List;

public interface ExamRecordService {
    List<ExamRecord> findAll();
    ExamRecord findById(Long id);
    List<ExamRecord> findByUserId(Long userId);
    List<ExamRecord> findByExamId(Long examId);
    List<ExamRecordInfo> findByUserIdAndExamId(Long userId, Long examId);
    ExamRecord save(ExamRecord examRecord);
    void deleteById(Long id);

    List<ExamRecord> findByUser_IdAndExam_Id(Long userId,Long examId);
}
