package com.elect.electexam.Service.lmp;

import com.elect.electexam.Enitity.ExamRecord;
import com.elect.electexam.Enitity.ExamRecordInfo;
import com.elect.electexam.Jpa.ExamRecordRepository;
import com.elect.electexam.Service.ExamRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ExamRecordServiceImpl implements ExamRecordService {
    @Autowired
    private ExamRecordRepository examRecordRepository;

    @Override
    public List<ExamRecord> findAll() {
        return examRecordRepository.findAll();
    }

    @Override
    public ExamRecord findById(Long id) {
        return examRecordRepository.findById(id).get();
    }

    @Override
    public List<ExamRecord> findByUserId(Long userId) {
        return examRecordRepository.findByUserId(userId);
    }

    @Override
    public List<ExamRecord> findByExamId(Long examId) {
        return examRecordRepository.findByExamId(examId);
    }

    @Override
    public List<ExamRecordInfo> findByUserIdAndExamId(Long userId, Long examId) {
        List<Object[]> results = examRecordRepository.findByUserIdAndExamId(userId, examId);

        List<ExamRecordInfo> examRecordInfos = new ArrayList<>();

        for (Object[] row : results) {
            ExamRecordInfo examRecordInfo = new ExamRecordInfo();
            examRecordInfo.setId(((Number) row[0]).intValue());
            examRecordInfo.setUsername((String) row[1]);
            examRecordInfo.setTitle((String) row[2]);
            examRecordInfo.setScore((Integer) row[3]);
            examRecordInfos.add(examRecordInfo);
        }
        return examRecordInfos;
    }

    @Override
    public ExamRecord save(ExamRecord examRecord) {
        return examRecordRepository.save(examRecord);
    }

    @Override
    public void deleteById(Long id) {
        findById(id); // Check if exam record exists
        examRecordRepository.deleteById(id);
    }

    @Override
    public List<ExamRecord> findByUser_IdAndExam_Id(Long userId, Long examId) {
        return examRecordRepository.findByUser_IdAndExam_Id(userId,examId);
    }
}
