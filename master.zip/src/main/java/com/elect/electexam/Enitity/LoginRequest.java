package com.elect.electexam.Enitity;

import lombok.Data;

@Data
public class LoginRequest {
    private String username;
    private String password;

    private boolean authlogin;

    private String type;

    // Getter and Setter methods
}
