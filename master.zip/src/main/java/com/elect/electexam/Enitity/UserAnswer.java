package com.elect.electexam.Enitity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Data;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


@Data
@Entity
@Table(name = "user_answers")
public class UserAnswer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "question_id", nullable = false)
    private Question question;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id", nullable = false)
    @JsonIgnore
    private Exam exam;

    @JsonProperty
    @Transient
    private Long questionId;

    @JsonProperty
    @Transient
    private Long userId;

    @JsonProperty
    @Transient
    private Long examId;

    @Column(name = "selected_options")
    private String selectedOptions;

    @Column(name = "answer_text")
    private String answerText;

    private Integer score;
    public List<Long> getSelectedOptionIds() {
        if (selectedOptions == null || selectedOptions.isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.stream(selectedOptions.split(","))
                .map(Long::parseLong)
                .collect(Collectors.toList());
    }

    public void setSelectedOptionIds(List<Long> selectedOptionIds) {
        if (selectedOptionIds == null || selectedOptionIds.isEmpty()) {
            selectedOptions = "";
        } else {
            selectedOptions = selectedOptionIds.stream()
                    .map(Object::toString)
                    .collect(Collectors.joining(","));
        }
    }

    // 省略 getter 和 setter
}
