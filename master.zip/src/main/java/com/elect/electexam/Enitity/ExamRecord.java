package com.elect.electexam.Enitity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@Entity
@Table(name = "exam_records")
@AllArgsConstructor
@NoArgsConstructor
public class ExamRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "exam_id", nullable = false)
    private Exam exam;

    @Column(name = "start_time", nullable = false)
    private Timestamp startTime;

    @Column(name = "end_time", nullable = false)
    private Timestamp endTime;

    @Column(nullable = false)
    private Integer score;

    // 省略 getter 和 setter

    // 在 ExamRecord 实体类中添加以下构造函数
    public ExamRecord(User user, Exam exam, Integer score) {
        this.user = user;
        this.exam = exam;
        this.score = score;
        this.startTime = new Timestamp(System.currentTimeMillis());
        this.endTime = new Timestamp(System.currentTimeMillis());
    }

}
