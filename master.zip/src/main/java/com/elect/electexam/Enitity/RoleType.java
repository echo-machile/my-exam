package com.elect.electexam.Enitity;

public enum RoleType {
    admin,
    user
}
