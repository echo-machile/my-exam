package com.elect.electexam.Enitity;

import lombok.Data;

import java.util.List;

@Data
public class UserAnswersWrapper {
    private List<UserAnswer> userAnswers;

    // Getter and Setter methods for 'userAnswers'
}
