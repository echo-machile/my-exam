package com.elect.electexam.Enitity;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class GradedScore {
    private Long userAnswerId;
    private Long userId;
    private Long examId;
    private Integer score;

    // 省略 getter 和 setter
}
